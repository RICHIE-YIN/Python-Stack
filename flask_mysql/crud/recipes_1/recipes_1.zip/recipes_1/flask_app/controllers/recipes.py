from flask_app import app, render_template, redirect, session, request
from flask_app.models.recipe import Recipe

@app.route('/recipes')
def recipes():
    if 'user_id' not in session:
        return redirect('/logout')
    return render_template('recipes.html', recipes = Recipe.get_all())

@app.route('/recipes/new')
def new_recipes():
    return render_template('new_recipe.html')

@app.route('/recipes/create', methods = ['POST'])
def create_recipe():
    if not Recipe.validate_recipe(request.form): #if name, description, and instructions are 3 characters+, redirect
        return redirect ('/recipes/new')
    Recipe.save(request.form)
    return redirect('/recipes')

@app.route('/recipes/<int:id>')
def show_recipe(id): #pass down id
    data = {'id' : id} #makes sure id in link matches id in data
    return render_template('show_recipe.html', recipe = Recipe.get_one(data)) #pass in recipe into html

@app.route('/recipes/edit/<int:id>')
def edit_recipe(id): #pass down id
    data = {'id' : id} #makes sure id in link matches id in data
    return render_template('edit_recipe.html', recipe = Recipe.get_one(data)) #pass in recipe into html

@app.route('/recipes/update', methods = ['POST'])
def update_recipe(id): #pass down id
    if not Recipe.validate_recipe(request.form): #if name, description, and instructions are 3 characters+, redirect
        return redirect (f"/recipes/edit/{request.form['id']}")
    Recipe.update(request.form) #else updates
    return redirect ('/recipes')

@app.route('/recipe/delete/<int:id>')
def delete(id):
    data ={
        'id': id
    }
    Recipe.delete(data)
    return redirect('/recipes')